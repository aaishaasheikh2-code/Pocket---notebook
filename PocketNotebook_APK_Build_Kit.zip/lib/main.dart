import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:cross_file/cross_file.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

const Color cream = Color(0xFFFFF8E9);
const Color green = Color(0xFF2E6B4F);
const Color darkGreen = Color(0xFF214D39);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PocketNotebookApp());
}

class NotebookPage {
  NotebookPage({
    required this.id,
    required this.title,
    required this.body,
    required this.updatedAt,
    this.favorite = false,
  });

  final String id;
  String title;
  String body;
  DateTime updatedAt;
  bool favorite;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'body': body,
        'updatedAt': updatedAt.toIso8601String(),
        'favorite': favorite,
      };

  factory NotebookPage.fromJson(Map<String, dynamic> json) => NotebookPage(
        id: json['id'] as String? ?? DateTime.now().microsecondsSinceEpoch.toString(),
        title: json['title'] as String? ?? '',
        body: json['body'] as String? ?? '',
        updatedAt: DateTime.tryParse(json['updatedAt'] as String? ?? '') ?? DateTime.now(),
        favorite: json['favorite'] as bool? ?? false,
      );
}

class PocketNotebookApp extends StatelessWidget {
  const PocketNotebookApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pocket Notebook',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(seedColor: green, brightness: Brightness.light),
        appBarTheme: const AppBarTheme(
          backgroundColor: cream,
          foregroundColor: darkGreen,
          elevation: 0,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white.withValues(alpha: 0.72),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
      ),
    ),
    home: const NotebookGate(),
    );
  }
}

class NotebookGate extends StatefulWidget {
  const NotebookGate({super.key});

  @override
  State<NotebookGate> createState() => _NotebookGateState();
}

class _NotebookGateState extends State<NotebookGate> {
  bool loading = true;
  bool locked = false;
  String pin = '';

  @override
  void initState() {
    super.initState();
    _loadLock();
  }

  Future<void> _loadLock() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      pin = prefs.getString('notebook_pin_v1') ?? '';
      locked = pin.isNotEmpty;
      loading = false;
    });
  }

  void _unlock() {
    setState(() => locked = false);
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator(color: green)));
    }
    if (locked) {
      return PinUnlockScreen(pin: pin, onUnlock: _unlock);
    }
    return const NotebookHome();
  }
}

class PinUnlockScreen extends StatefulWidget {
  const PinUnlockScreen({super.key, required this.pin, required this.onUnlock});
  final String pin;
  final VoidCallback onUnlock;

  @override
  State<PinUnlockScreen> createState() => _PinUnlockScreenState();
}

class _PinUnlockScreenState extends State<PinUnlockScreen> {
  final controller = TextEditingController();
  String? error;

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void _tryUnlock() {
    if (controller.text == widget.pin) {
      widget.onUnlock();
    } else {
      setState(() {
        error = 'PIN सही नहीं है। दोबारा कोशिश करें।';
        controller.clear();
      });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 360),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.lock_rounded, size: 58, color: green),
                    const SizedBox(height: 18),
                    const Text('Pocket Notebook', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: darkGreen)),
                    const SizedBox(height: 8),
                    const Text('अपने नोट्स खोलने के लिए PIN डालें'),
                    const SizedBox(height: 22),
                    TextField(
                      controller: controller,
                      obscureText: true,
                      keyboardType: TextInputType.number,
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(8)],
                      decoration: InputDecoration(hintText: '4–8 अंकों का PIN', errorText: error),
                      onSubmitted: (_) => _tryUnlock(),
                    ),
                    const SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: _tryUnlock,
                        style: FilledButton.styleFrom(backgroundColor: green, padding: const EdgeInsets.symmetric(vertical: 14)),
                        child: const Text('अनलॉक करें'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
}

class NotebookHome extends StatefulWidget {
  const NotebookHome({super.key});

  @override
  State<NotebookHome> createState() => _NotebookHomeState();
}

class _NotebookHomeState extends State<NotebookHome> {
  List<NotebookPage> pages = [];
  int currentIndex = 0;
  bool loading = true;
  Timer? saveTimer;
  final titleController = TextEditingController();
  final bodyController = TextEditingController();
  bool syncingControllers = false;

  NotebookPage get currentPage => pages[currentIndex];

  @override
  void initState() {
    super.initState();
    _loadPages();
    titleController.addListener(_onTextChanged);
    bodyController.addListener(_onTextChanged);
  }

  Future<void> _loadPages() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('notebook_pages_v1');
    List<NotebookPage> loaded = [];
    if (raw != null) {
      try {
        loaded = (jsonDecode(raw) as List<dynamic>)
            .map((item) => NotebookPage.fromJson(Map<String, dynamic>.from(item as Map)))
            .toList();
      } catch (_) {
        loaded = [];
      }
    }
    if (loaded.isEmpty) {
      loaded = [NotebookPage(id: DateTime.now().microsecondsSinceEpoch.toString(), title: '', body: '', updatedAt: DateTime.now())];
    }
    if (!mounted) return;
    setState(() {
      pages = loaded;
      currentIndex = 0;
      loading = false;
    });
    _syncControllers();
    await _savePages();
  }

  void _syncControllers() {
    if (pages.isEmpty) return;
    syncingControllers = true;
    titleController.text = currentPage.title;
    bodyController.text = currentPage.body;
    syncingControllers = false;
  }

  void _onTextChanged() {
    if (syncingControllers || loading || pages.isEmpty) return;
    currentPage.title = titleController.text;
    currentPage.body = bodyController.text;
    currentPage.updatedAt = DateTime.now();
    saveTimer?.cancel();
    saveTimer = Timer(const Duration(milliseconds: 350), _savePages);
    setState(() {});
  }

  Future<void> _savePages() async {
    if (pages.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('notebook_pages_v1', jsonEncode(pages.map((page) => page.toJson()).toList()));
  }

  Future<void> _newPage() async {
    await _savePages();
    setState(() {
      pages.add(NotebookPage(id: DateTime.now().microsecondsSinceEpoch.toString(), title: '', body: '', updatedAt: DateTime.now()));
      currentIndex = pages.length - 1;
    });
    _syncControllers();
  }

  void _goToPage(int index) {
    if (index < 0 || index >= pages.length) return;
    FocusScope.of(context).unfocus();
    setState(() => currentIndex = index);
    _syncControllers();
  }

  Future<void> _toggleFavorite() async {
    setState(() => currentPage.favorite = !currentPage.favorite);
    await _savePages();
  }

  void _showIndex({bool favoritesOnly = false}) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: cream,
      builder: (sheetContext) {
        final items = pages.asMap().entries.where((entry) => !favoritesOnly || entry.value.favorite).toList();
        return SafeArea(
          child: SizedBox(
            height: MediaQuery.of(sheetContext).size.height * 0.75,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 18, 12, 8),
                  child: Row(
                    children: [
                      Expanded(child: Text(favoritesOnly ? 'पसंदीदा पन्ने' : 'पन्नों की सूची', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold, color: darkGreen))),
                      IconButton(onPressed: () => Navigator.pop(sheetContext), icon: const Icon(Icons.close)),
                    ],
                  ),
                ),
                Expanded(
                  child: items.isEmpty
                      ? const Center(child: Text('अभी कोई पन्ना नहीं है।'))
                      : ListView.separated(
                          itemCount: items.length,
                          separatorBuilder: (_, __) => const Divider(height: 1, indent: 20, endIndent: 20),
                          itemBuilder: (context, i) {
                            final entry = items[i];
                            final page = entry.value;
                            final title = page.title.trim().isEmpty ? 'बिना शीर्षक' : page.title.trim();
                            final preview = page.body.trim().replaceAll('\n', ' ');
                            return ListTile(
                              leading: CircleAvatar(backgroundColor: green.withValues(alpha: 0.12), foregroundColor: green, child: Text('${entry.key + 1}')),
                              title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis),
                              subtitle: Text(preview.isEmpty ? 'खाली पन्ना' : preview, maxLines: 1, overflow: TextOverflow.ellipsis),
                              trailing: page.favorite ? const Icon(Icons.star, color: green) : null,
                              onTap: () {
                                Navigator.pop(sheetContext);
                                _goToPage(entry.key);
                              },
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _searchPages() {
    showSearch<NotebookPage?>(context: context, delegate: NotebookSearchDelegate(pages)).then((result) {
      if (result == null) return;
      final index = pages.indexWhere((page) => page.id == result.id);
      if (index >= 0) _goToPage(index);
    });
  }

  Future<void> _exportPdf() async {
    await _savePages();
    final doc = pw.Document();
    for (var i = 0; i < pages.length; i++) {
      final page = pages[i];
      if (page.title.trim().isEmpty && page.body.trim().isEmpty) continue;
      doc.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(42),
          build: (_) => pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text('Pocket Notebook  •  Page ${i + 1}', style: pw.TextStyle(fontSize: 10, color: PdfColors.grey700)),
              pw.SizedBox(height: 18),
              pw.Text(page.title.trim().isEmpty ? 'Untitled' : page.title.trim(),
                  style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 16),
              pw.Expanded(child: pw.Text(page.body, style: const pw.TextStyle(fontSize: 12, lineSpacing: 4))),
            ],
          ),
        ),
      );
    }
    if (doc.pages.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PDF बनाने के लिए कोई लिखा हुआ नोट नहीं है।')));
      return;
    }
    final bytes = await doc.save();
    await Printing.sharePdf(bytes: bytes, filename: 'pocket_notebook.pdf');
  }

  Future<void> _backupJson() async {
    await _savePages();
    final data = {
      'app': 'Pocket Notebook',
      'formatVersion': 1,
      'exportedAt': DateTime.now().toIso8601String(),
      'pages': pages.map((page) => page.toJson()).toList(),
    };
    final bytes = Uint8List.fromList(utf8.encode(const JsonEncoder.withIndent('  ').convert(data)));
    final file = XFile.fromData(bytes, mimeType: 'application/json', name: 'pocket_notebook_backup.json');
    await Share.shareXFiles([file], text: 'Pocket Notebook backup');
  }

  Future<void> _managePin() async {
    final prefs = await SharedPreferences.getInstance();
    final existing = prefs.getString('notebook_pin_v1') ?? '';
    final controller = TextEditingController();
    final formKey = GlobalKey<FormState>();
    final result = await showDialog<String?>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(existing.isEmpty ? 'PIN सेट करें' : 'PIN बदलें या हटाएँ'),
        content: Form(
          key: formKey,
          child: TextFormField(
            controller: controller,
            autofocus: true,
            obscureText: true,
            keyboardType: TextInputType.number,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(8)],
            decoration: const InputDecoration(labelText: 'नया PIN (4–8 अंक)', helperText: 'PIN हटाने के लिए खाली छोड़ें'),
            validator: (value) {
              final v = value ?? '';
              if (v.isNotEmpty && v.length < 4) return 'कम से कम 4 अंक डालें।';
              return null;
            },
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext, null), child: const Text('रद्द करें')),
          FilledButton(
            onPressed: () {
              if (formKey.currentState!.validate()) Navigator.pop(dialogContext, controller.text);
            },
            child: const Text('सेव करें'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (result == null) return;
    if (result.isEmpty) {
      await prefs.remove('notebook_pin_v1');
    } else {
      await prefs.setString('notebook_pin_v1', result);
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(result.isEmpty ? 'ऐप PIN लॉक हटा दिया गया।' : 'PIN सेव हो गया। अगली बार ऐप खोलने पर लॉक दिखेगा।')),
    );
  }

  void _showTools() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: cream,
      builder: (sheetContext) => SafeArea(
        child: Wrap(
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 20, 20, 6),
              child: Text('टूल्स और बैकअप', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold, color: darkGreen)),
            ),
            ListTile(leading: const Icon(Icons.picture_as_pdf, color: green), title: const Text('PDF में एक्सपोर्ट करें'), subtitle: const Text('लिखे हुए पन्नों की PDF साझा करें'), onTap: () { Navigator.pop(sheetContext); _exportPdf(); }),
            ListTile(leading: const Icon(Icons.backup_outlined, color: green), title: const Text('JSON बैकअप साझा करें'), subtitle: const Text('नोट्स की बैकअप फ़ाइल बनाएँ'), onTap: () { Navigator.pop(sheetContext); _backupJson(); }),
            ListTile(leading: const Icon(Icons.lock_outline, color: green), title: const Text('ऐप PIN लॉक'), subtitle: const Text('4–8 अंकों का PIN सेट या हटाएँ'), onTap: () { Navigator.pop(sheetContext); _managePin(); }),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    saveTimer?.cancel();
    titleController.dispose();
    bodyController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator(color: green)));
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Pocket Notebook', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 21)),
            Text('आपके छोटे-छोटे ज़रूरी नोट्स', style: TextStyle(fontSize: 12, color: Colors.black54)),
          ],
        ),
        actions: [
          IconButton(tooltip: 'खोजें', onPressed: _searchPages, icon: const Icon(Icons.search)),
          IconButton(tooltip: 'पसंदीदा', onPressed: () => _showIndex(favoritesOnly: true), icon: const Icon(Icons.star_border_rounded)),
          IconButton(tooltip: 'टूल्स', onPressed: _showTools, icon: const Icon(Icons.more_vert)),
          const SizedBox(width: 4),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 12),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(color: green.withValues(alpha: 0.09), borderRadius: BorderRadius.circular(14)),
                child: Row(
                  children: [
                    const Icon(Icons.menu_book_rounded, color: green),
                    const SizedBox(width: 9),
                    Expanded(child: Text('पन्ना ${currentIndex + 1} / ${pages.length}', style: const TextStyle(fontWeight: FontWeight.w700, color: darkGreen))),
                    IconButton(tooltip: currentPage.favorite ? 'पसंदीदा हटाएँ' : 'पसंदीदा बनाएँ', visualDensity: VisualDensity.compact, onPressed: _toggleFavorite, icon: Icon(currentPage.favorite ? Icons.star_rounded : Icons.star_border_rounded, color: currentPage.favorite ? Colors.orange.shade700 : green)),
                    IconButton(tooltip: 'पन्नों की सूची', visualDensity: VisualDensity.compact, onPressed: () => _showIndex(), icon: const Icon(Icons.list_alt_rounded, color: green)),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFFDF7),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: const Color(0xFFE9E0CE)),
                    boxShadow: [BoxShadow(color: Colors.brown.withValues(alpha: 0.05), blurRadius: 14, offset: const Offset(0, 5))],
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(18, 14, 18, 4),
                        child: TextField(
                          controller: titleController,
                          textCapitalization: TextCapitalization.sentences,
                          decoration: const InputDecoration(hintText: 'पन्ने का शीर्षक (वैकल्पिक)', filled: false, contentPadding: EdgeInsets.symmetric(vertical: 10)),
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: darkGreen),
                        ),
                      ),
                      const Divider(height: 1, indent: 18, endIndent: 18, color: Color(0xFFE9E0CE)),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(18, 8, 18, 14),
                          child: TextField(
                            controller: bodyController,
                            expands: true,
                            minLines: null,
                            maxLines: null,
                            keyboardType: TextInputType.multiline,
                            textCapitalization: TextCapitalization.sentences,
                            textAlignVertical: TextAlignVertical.top,
                            decoration: const InputDecoration(hintText: 'यहाँ लिखना शुरू करें…\n\nआपके नोट अपने आप सेव होते रहेंगे।', filled: false, contentPadding: EdgeInsets.zero),
                            style: const TextStyle(fontSize: 17, height: 1.55, color: Color(0xFF34352F)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: OutlinedButton.icon(onPressed: currentIndex > 0 ? () => _goToPage(currentIndex - 1) : null, icon: const Icon(Icons.chevron_left_rounded), label: const Text('पिछला'), style: OutlinedButton.styleFrom(foregroundColor: green, side: const BorderSide(color: green), padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))))),
                  const SizedBox(width: 10),
                  Expanded(child: FilledButton.icon(onPressed: _newPage, icon: const Icon(Icons.add_rounded), label: const Text('नया पन्ना'), style: FilledButton.styleFrom(backgroundColor: green, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))))),
                  const SizedBox(width: 10),
                  Expanded(child: OutlinedButton.icon(onPressed: currentIndex < pages.length - 1 ? () => _goToPage(currentIndex + 1) : null, icon: const Icon(Icons.chevron_right_rounded), label: const Text('अगला'), style: OutlinedButton.styleFrom(foregroundColor: green, side: const BorderSide(color: green), padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))))),
                ],
              ),
              const SizedBox(height: 4),
              const Text('ऑफलाइन • ऑटो-सेव', style: TextStyle(fontSize: 12, color: Colors.black54)),
            ],
          ),
        ),
      ),
    );
  }
}

class NotebookSearchDelegate extends SearchDelegate<NotebookPage?> {
  NotebookSearchDelegate(this.pages);
  final List<NotebookPage> pages;

  @override
  String get searchFieldLabel => 'नोट्स में खोजें';

  @override
  ThemeData appBarTheme(BuildContext context) => Theme.of(context).copyWith(
        appBarTheme: const AppBarTheme(backgroundColor: cream, foregroundColor: darkGreen),
        scaffoldBackgroundColor: cream,
      );

  @override
  List<Widget> buildActions(BuildContext context) => [IconButton(onPressed: () => query = '', icon: const Icon(Icons.clear))];

  @override
  Widget buildLeading(BuildContext context) => IconButton(onPressed: () => close(context, null), icon: const Icon(Icons.arrow_back));

  @override
  Widget buildResults(BuildContext context) => _results();

  @override
  Widget buildSuggestions(BuildContext context) => _results();

  Widget _results() {
    final q = query.trim().toLowerCase();
    final matches = pages.asMap().entries.where((entry) {
      if (q.isEmpty) return true;
      final page = entry.value;
      return page.title.toLowerCase().contains(q) || page.body.toLowerCase().contains(q);
    }).toList();
    if (matches.isEmpty) return const Center(child: Text('कोई मिलान नहीं मिला।'));
    return ListView.separated(
      itemCount: matches.length,
      separatorBuilder: (_, __) => const Divider(height: 1),
      itemBuilder: (context, i) {
        final entry = matches[i];
        final page = entry.value;
        return ListTile(
          leading: CircleAvatar(backgroundColor: green.withValues(alpha: 0.12), foregroundColor: green, child: Text('${entry.key + 1}')),
          title: Text(page.title.trim().isEmpty ? 'बिना शीर्षक' : page.title, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(page.body.trim().isEmpty ? 'खाली पन्ना' : page.body, maxLines: 2, overflow: TextOverflow.ellipsis),
          onTap: () => close(context, page),
        );
      },
    );
  }
}
