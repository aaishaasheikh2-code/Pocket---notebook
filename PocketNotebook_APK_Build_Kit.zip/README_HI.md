# Pocket Notebook — APK Build Kit

इस पैकेज में Flutter ऐप का source code और GitHub Actions workflow है, जो cloud runner पर Android APK बनाने की कोशिश करेगा।

## APK बनाने का आसान तरीका (कंप्यूटर पर)
1. इस ZIP को extract करें।
2. GitHub पर नया repository बनाएँ और इस folder की सभी files upload करें।
3. Repository में `Actions` tab खोलें।
4. अगर workflow अपने आप शुरू नहीं हुआ, `Build Android APK` चुनें और `Run workflow` दबाएँ।
5. Build पूरा होने पर run के अंदर `pocket-notebook-release-apk` नाम का artifact डाउनलोड करें। उसके अंदर `app-release.apk` होगी।

## जरूरी सावधानी
- यह तरीका GitHub account और repository इस्तेमाल करता है; repository को public करने की जरूरत नहीं, private repository भी इस्तेमाल की जा सकती है।
- Workflow source को cloud runner पर build करने के लिए है; इस चैट में APK compile या device-test नहीं की गई।
- पहली बार build में generated Android wrapper और current Flutter dependencies के कारण सुधार की ज़रूरत पड़ सकती है।
- ऐप का package ID अभी `com.example.pocket_notebook` है; Play Store release से पहले इसे अपने स्थायी unique ID में बदलना चाहिए।
- PIN इस starter में simple app-level PIN है, secure encryption नहीं।
- JSON backup export उपलब्ध है, लेकिन import/restore अभी शामिल नहीं है।
- नोट्स device-local हैं; uninstall/app data clear करने पर मिट सकते हैं।
